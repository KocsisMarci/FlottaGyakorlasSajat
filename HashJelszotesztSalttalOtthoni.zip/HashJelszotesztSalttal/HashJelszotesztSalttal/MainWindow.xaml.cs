﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text;
using Argon2Sharp;

namespace HashJelszotesztSalttal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private string hash=null;
        public void bejelentkezes(object sender, RoutedEventArgs e) {
            if (uname.Text != "" && password.Text != "")
            {
                string result = Argon2PhcFormat.HashToPhcStringWithAutoSalt(password.Text);
                hash = result;

                MessageBox.Show($"Na ez lett az eredmény: {hash}");
            }

            else
            {
                MessageBox.Show("Hiányzó adat");
            }
        }


        public void mentes(object sender, RoutedEventArgs e) {
            if (hash != null)
            {
                File.WriteAllText("legujabbTeszt.txt", hash);
                MessageBox.Show("Sikeres mentés történt");
            }

            else
            {
                MessageBox.Show("Nincs mit menteni");
            }
        
        }
    }
}